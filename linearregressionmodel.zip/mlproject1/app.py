from flask import Flask, render_template, request
import numpy as np

app = Flask(__name__)

# Linear regression model and related functions
class Neuron:
    def __init__(self, itr):
        self.weights = None
        self.bias = None
        self.n_itr = itr

    def fit(self, X, y, learning_rate):
        n_samples, n_features = X.shape
        self.weights = np.full(n_features, 9.0)
        self.bias = 0

        for _ in range(self.n_itr):
            y_pred = np.dot(X, self.weights) + self.bias
            dw = (2 / n_samples) * np.dot((y_pred - y).T, X)
            db = (2 / n_samples) * (np.sum(y_pred - y))
            self.weights -= learning_rate * dw
            self.bias -= learning_rate * db

    def predict(self, X):
        if self.weights is None or self.bias is None:
            raise ValueError("Model is not trained. Call fit method first.")
        return np.dot(X, self.weights) + self.bias

# Initialize and train the model
reg = Neuron(itr=300000)
X_train = np.array([[7.5], [8.0], [8.5], [9.0], [9.5]])
y_train = np.array([70, 75, 80, 85, 90])
reg.fit(X_train, y_train, learning_rate=0.000001)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    if request.method == 'POST':
        cgpa = float(request.form['cgpa'])
        result = reg.predict(np.array([[cgpa]]))
        return render_template('result.html', prediction=result[0])
    return redirect(url_for('index.html'))

if __name__ == '__main__':
    app.run(debug=True)
