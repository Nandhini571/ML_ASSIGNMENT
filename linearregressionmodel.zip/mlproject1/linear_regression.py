import numpy as np

def activation_func(x):
    return x

def cal_error(y, y_pred):
    return np.mean((y_pred - y) ** 2)

class Neuron:
    def __init__(self, itr):
        self.weights = None
        self.bias = None
        self.activation_function = activation_func
        self.n_itr = itr
        self.error = 0
        self.lr = 0

    def fit(self, X, y, learning_rate):
        min_error = 0.1
        n_samples, n_features = X.shape
        self.weights = np.full(n_features, 9.0)  # Ensure weights are float type
        self.bias = 0
        self.lr = learning_rate

        for _ in range(self.n_itr):
            y_pred = np.dot(X, self.weights) + self.bias
            self.error = cal_error(y, y_pred)
            if self.error > min_error:
                dw = (2 / n_samples) * np.dot((y_pred - y).T, X)
                db = (2 / n_samples) * (np.sum(y_pred - y))

                # Convert dw to the same data type as self.weights
                dw = dw.astype(self.weights.dtype)

                self.weights -= self.lr * dw
                self.bias -= self.lr * db

    def predict(self, X):
        if self.weights is None or self.bias is None:
            raise ValueError("Model is not trained. Call fit method first.")
        y_pred = np.dot(X, self.weights) + self.bias
        # Assuming percentage is directly predicted
        return y_pred

if __name__ == "__main__":
    # Example usage or testing if run directly
    # Assuming you have training data X and y
    X_train = np.array([[7.5], [8.0], [8.5], [9.0], [9.5]])
    y_train = np.array([75, 80, 85, 90, 95])

    # Initialize and train the neuron
    reg = Neuron(itr=300000)
    reg.fit(X_train, y_train, learning_rate=0.000001)

    # Example prediction
    cgpa = 7.93  # Example CGPA
    result = reg.predict(np.array([[cgpa]]))
    print("Predicted Percentage:", result[0])
